/******************************************************
** Program: program1.cpp
** Author: Senna Titcomb
** Date: 04/12/20
** Description: A spellbook catalog program that takes in two files and then user information including a valid ID and password. 
**The program will read in files based on the user information, print out information within the files, sort out given information, as well as write out the sorted information into a new file and be able to quit.
** The program will be able to sort the spellbook by the number of pages, group spells by their effect and sort by the average success rate of the spells.	
** Input: User ID and password, the Sorting choice, the decision to print the sorted information to the screen or to a file, as well as the file name
** Output: The user information, the user choices of sorting or quitting, and the sorted information
******************************************************/
#include <iostream>
#include <stdlib.h>
#include <string>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>

using namespace std;

struct wizards{
    string Name;
    int ID;
    string pw;
    string title;
    int beard;

};

struct spellbook {
  string title;
  string author;
  int num_pages;
  int edition;
  int num_spells;
  float avg_success_rate;
  struct spell *s;
};

struct spell {
  string name;
  float success_rate;
  string effect; 
};

bool get_int(string);
int string_convert(string);
wizards* create_wizarddb(int);
spellbook* create_spellbooks(int);
spell* create_spells(int);
void get_wizards(wizards* , int , ifstream & );
void pw_check(wizards*, spellbook*, int, int, ifstream &, ifstream &);
void get_spellbook_data(spellbook*, int, ifstream &);
void get_spell_data(spell*, int, ifstream &);
void sort_pages(spellbook*, int, ifstream &);
void pageopt(spellbook*, int, ifstream &);
void sort_effect(spellbook*, int, ifstream &);
void effectopt(spellbook*, int, ifstream &);
void sort_avg(spellbook*, int, ifstream &);
void avgopt(spellbook*, int, ifstream &);
bool hasevil(spellbook * spellbookdb, int i, int y, ifstream & fi);
void studentsort_pages(spellbook*, int, ifstream &);
void studentpageopt(spellbook*, int, ifstream &);
void studentsort_effect(spellbook*, int, ifstream &);
void studenteffectopt(spellbook*, int, ifstream &);
void studentsort_avg(spellbook*, int, ifstream &);
void studentavgopt(spellbook*, int, ifstream &);
void options(wizards*, spellbook * , int, int , ifstream & );
void studentoptions(spellbook *, int, ifstream &);
void delete_info(wizards *, spellbook *);