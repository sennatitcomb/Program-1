#include "./programfunct.h"

/*************************************************************************************************************************************
** Function: get_int()
** Description: Takes a prompt from the user as a string literal, checks if input is a valid integer, returns the provided integer.
** Parameters: string prompt
** Pre-conditions: take a string parameter
** Post-conditions: return the provided integer.
*************************************************************************************************************************************/
bool get_int(string prompt) {
    for (int x = 0; x < prompt.length(); x++) {
        if ((int) prompt[x] < 48 || (int) prompt[x] > 57) {
            return false;
        }
    }

    return true;
}
/*************************************************************************************************************************************
** Function: string_convert()
** Description: Converts the string to an integer
** Parameters: string number
** Pre-conditions: take a string number
** Post-conditions: return the integer
*************************************************************************************************************************************/
int string_convert(string number) {
    int newNumber = 0;

    for (int x = 0; x < number.length(); x++)
        newNumber += ((int) number[x] - 48) * pow(10, (number.length() - 1 - x));

    return newNumber;
}

/*************************************************************************************************************************************
** Function: create_wizarddb()
** Description: Takes in an int x to create an array.
** Parameters: int x
** Pre-conditions: take a int x
** Post-conditions: return the new array.
*************************************************************************************************************************************/
wizards* create_wizarddb(int x) {
    wizards* wizarddb = new wizards[x];

    return wizarddb;  
}
/*************************************************************************************************************************************
** Function: create_spellbooks()
** Description: Takes in an int y to create an array.
** Parameters: int y
** Pre-conditions: take a int y
** Post-conditions: return the new array.
*************************************************************************************************************************************/
spellbook * create_spellbooks(int y) {
    spellbook* spellbookdb = new spellbook[y];

    return spellbookdb;
}

/*************************************************************************************************************************************
** Function: create_spells()
** Description: Takes in an int z to create an array.
** Parameters: int z
** Pre-conditions: take a int z
** Post-conditions: return the new array.
*************************************************************************************************************************************/
spell * create_spells(int z) {
    spell* spelldb = new spell[z];

    return spelldb;
}

/*************************************************************************************************************************************
** Function: get_wizards()
** Description: Read in each line and store it in the array using structs
** Parameters: wizards * wizarddb, int x, ifstream & f
** Pre-conditions: take wizards * wizarddb, int x, ifstream & f
** Post-conditions: return nothing
*************************************************************************************************************************************/
void get_wizards(wizards * wizarddb, int x, ifstream & f) {
    //the & symbol is for reference
    string input;
    for (int i = 0; i < x; i++){
        getline(f, input, ' ');
        wizarddb[i].Name = input;
        getline(f, input, ' ');
        wizarddb[i].ID = string_convert(input);
        getline(f, input, ' ');
        wizarddb[i].pw = input;
        getline(f, input, ' ');
        wizarddb[i].title = input;
        getline(f, input, '\n');
        wizarddb[i].beard = string_convert(input);
    }  
  /*  for(int h = 0; h < x; h ++) {
            cout << wizarddb[h].Name << " " << wizarddb[h].ID << " " << wizarddb[h].pw << " " << wizarddb[h].title << " " << wizarddb[h].beard << endl;
     } */
}

/*************************************************************************************************************************************
** Function: pw_check()
** Description: Checks the ID and PW of the User
** Parameters: wizards * wizarddb, int x, ifstream & f
** Pre-conditions: take wizards * wizarddb, int x, ifstream & f
** Post-conditions: return User information
*************************************************************************************************************************************/
void pw_check(wizards * wizarddb, spellbook* spellbookdb, int x, int y, ifstream & f, ifstream & fi) {
        string ID, pw;
        int count = 0;
        while (count < 3) {
            bool valid = false;
            cout << "Please enter your ID: ";
            cin >> ID;
            cout << "Please enter your password: ";
            cin >> pw;
            for(int h = 0; h < x; h ++) {
            //for loop goes through each of ID possibilities
                if(get_int(ID) == true and (string_convert(ID) == wizarddb[h].ID) and (pw == wizarddb[h].pw)) {
                    //compares entered ID to possible IDs
                    //if they are equal, do this
                    cout << "Welcome " << wizarddb[h].Name << "\n" << "ID: " << wizarddb[h].ID << "\n" << "Status: " << wizarddb[h].title << "\n" << "Beard Length: " << wizarddb[h].beard << endl;
                    count = 3;
                    valid = true;     
                    options(wizarddb, spellbookdb, h, y, fi);               
                } 
            } 
            if (valid == false and (get_int(ID) == true)) {
                cout << "Incorrect ID or password" << endl;
                count ++;
            } else if (get_int(ID) == false){
                    cout << "Please enter a valid ID" << endl;         
            }
        }
}

/*************************************************************************************************************************************
** Function: get_spell_data()
** Description: Read in each line and store it in the array using structs
** Parameters: spell * spelldb, int z, ifstream & fi
** Pre-conditions: take in spell * spelldb, int z, ifstream & fi
** Post-conditions: return nothing
*************************************************************************************************************************************/
void get_spell_data(spell * spelldb, int z, ifstream & fi) {
    string input;
    for (int i = 0; i < z; i++){
            getline(fi, input, ' ');
            spelldb[i].name = input;
            getline(fi, input, ' ');
            spelldb[i].success_rate = stof(input);
            //stof changes to float
            getline(fi, input, '\n');
            spelldb[i].effect = input; 
    }  

    /*for(int h = 0; h < z; h ++) {
            cout << spelldb[h].name << " " << spelldb[h].success_rate << " " << spelldb[h].effect << endl;
     }  */

} 

/*************************************************************************************************************************************
** Function: get_spellbook_data()
** Description: Read in each line and store it in the array using structs
** Parameters: spellbook * spellbookdb, int z, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return nothing
*************************************************************************************************************************************/
void get_spellbook_data(spellbook * spellbookdb, int y, ifstream & fi) {
    string input;
    for (int i = 0; i < y; i++){
        //how many spellbooks there are 
            getline(fi, input, ' ');
            spellbookdb[i].title = input;
            getline(fi, input, ' ');
            spellbookdb[i].author = input;
            getline(fi, input, ' ');
            spellbookdb[i].num_pages = string_convert(input);
            getline(fi, input, ' ');
            spellbookdb[i].edition = string_convert(input);
            getline(fi, input, '\n');
            spellbookdb[i].num_spells = string_convert(input);
            spellbookdb[i].s = create_spells(spellbookdb[i].num_spells);
            //creates array of spells
            get_spell_data(spellbookdb[i].s, spellbookdb[i].num_spells, fi);
        /*for (int k = 0; k < spellbookdb[i].num_spells; k++) {
            //int total = 0;
            //total++;
            //read spell lines for number of spells in book
            

        } */
    }  

   /* for(int h = 0; h < y; h ++) {
            cout << spellbookdb[h].title << " " << spellbookdb[h].author << " " << spellbookdb[h].num_spells << endl;
     }  */

}

/*************************************************************************************************************************************
** Function: sort_pages()
** Description: Looks at array and compares number of pages of each spellbook and reorders
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: sorts according to number of pages
*************************************************************************************************************************************/
void sort_pages(spellbook * spellbookdb, int y, ifstream & fi) {
    spellbook hold;
    for(int i = 0; i < y; i ++) {
        for(int j = i; j < y; j++) {
            if (spellbookdb[i].num_pages > spellbookdb[j].num_pages) {
                hold = spellbookdb[j];
                spellbookdb[j] = spellbookdb[i];
                spellbookdb[i] = hold;

            }
        }
    }
    pageopt(spellbookdb, y, fi);
    
}
/*************************************************************************************************************************************
** Function: pageopt()
** Description: Asks user which display option they prefer
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void pageopt(spellbook * spellbookdb, int y, ifstream & fi) {
    int i = 0;
    cout << "How would you like the information displayed?" << endl;
    cout << "Print to screen (Press 1)" << endl;
    cout << "Print to file (Press 2)" << endl;
    cin >> i;
    if (i == 1) {
        for(int h = 0; h < y; h ++) {
            cout << spellbookdb[h].title << " " << spellbookdb[h].num_pages << endl;
        }
    } else if (i == 2) {
        string filename;
        cout << "Please provide the desired filename." << endl;
        cin >> filename;
        ofstream fx(filename, ofstream::trunc);
        for(int h = 0; h < y; h ++) {
            fx << spellbookdb[h].title << " " << spellbookdb[h].num_pages << endl;
        }
        cout << "Appended request information to file." << endl;
    }

}
/*************************************************************************************************************************************
** Function: sort_effect()
** Description: Looks at array and compares effects of spells in each spellbook and groups and prints to screen
** Parameters: spellbook * spellbookdb, int z, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int z, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void sort_effect(spellbook * spellbookdb, int y, ifstream & fi) {
    int i = 0;
    cout << "How would you like the information displayed?" << endl;
    cout << "Print to screen (Press 1)" << endl;
    cout << "Print to file (Press 2)" << endl;
    cin >> i;
    if (i == 1) {
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "bubble") {
                    cout << "bubble " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "memory_loss") {
                    cout << "memory_loss " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "fire") {
                    cout << "fire " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "poison") {
                    cout << "poison " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "death") {
                    cout << "death " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
    } else if (i == 2) {
        effectopt(spellbookdb, y, fi);
    }
}

/*************************************************************************************************************************************
** Function: effectopt()
** Description: Prints sorted information to file
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to file
*************************************************************************************************************************************/
void effectopt(spellbook * spellbookdb, int y, ifstream & fi) {
        ofstream fx("outputs.txt", ofstream::trunc);
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "bubble") {
                    cout << "bubble " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "memory_loss") {
                    cout << "memory_loss " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "fire") {
                    cout << "fire " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "poison") {
                    cout << "poison " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "death") {
                    cout << "death " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
}
/*************************************************************************************************************************************
** Function: sort_avg()
** Description: Looks at array and compares success rate of each spellbook and reorders
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void sort_avg(spellbook * spellbookdb, int y, ifstream & fi) {
    //sort by avg success rate
    for(int g = 0; g < y; g ++) {
        float total = 0;
        for(int k = 0; k < spellbookdb[g].num_spells; k ++) {
            total = total + spellbookdb[g].s[k].success_rate;
        }
        total = total/(spellbookdb[g].num_spells);
        spellbookdb[g].avg_success_rate = total;
    }
    spellbook hold;
    for(int i = 0; i < y; i ++) {
        for(int j = i; j < y; j++) {
            if (spellbookdb[i].avg_success_rate > spellbookdb[j].avg_success_rate) {
                hold = spellbookdb[j];
                spellbookdb[j] = spellbookdb[i];
                spellbookdb[i] = hold;

            }
        }
    }
    
     avgopt(spellbookdb, y, fi);
}

/*************************************************************************************************************************************
** Function: avgopt()
** Description: Asks user which display option they prefer
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void avgopt(spellbook * spellbookdb, int y, ifstream & fi) {
    int i = 0;
    cout << "How would you like the information displayed?" << endl;
    cout << "Print to screen (Press 1)" << endl;
    cout << "Print to file (Press 2)" << endl;
    cin >> i;
    if (i == 1) {
        for(int h = 0; h < y; h ++) {
            cout << spellbookdb[h].title << " " << spellbookdb[h].avg_success_rate  << endl;
     }
    } else if (i == 2) {
        string filename;
        cout << "Please provide the desired filename." << endl;
        cin >> filename;
        ofstream fx(filename, ofstream::trunc);
        for(int h = 0; h < y; h ++) {
            fx << spellbookdb[h].title << " " << spellbookdb[h].avg_success_rate  << endl;
        }
        cout << "Appended request information to file." << endl;
    }

}

/*************************************************************************************************************************************
** Function: hasevil()
** Description: Looks at spells and sees if they contain posion or death
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: returns true or false
*************************************************************************************************************************************/
bool hasevil(spellbook * spellbookdb, int i, int y, ifstream & fi) {
    for(int j = 0; j < spellbookdb[i].num_spells; j++) {
        if (spellbookdb[i].s[j].effect == "poison" or spellbookdb[i].s[j].effect == "death") {
            return true;
        }
    }
    return false;
}
/*************************************************************************************************************************************
** Function: studentsort_pages()
** Description: Looks at array and compares number of pages of each spellbook and reorders
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: sorts according to number of pages
*************************************************************************************************************************************/
void studentsort_pages(spellbook * spellbookdb, int y, ifstream & fi) {
    spellbook hold;
    for(int i = 0; i < y; i ++) {
        for(int j = i; j < y; j++) {
            if (spellbookdb[i].num_pages > spellbookdb[j].num_pages) {
                hold = spellbookdb[j];
                spellbookdb[j] = spellbookdb[i];
                spellbookdb[i] = hold;

            }
        }
    }
    studentpageopt(spellbookdb, y, fi);
    
}
/*************************************************************************************************************************************
** Function: studentpageopt()
** Description: Asks user which display option they prefer
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void studentpageopt(spellbook * spellbookdb, int y, ifstream & fi) {
    int i = 0;
    cout << "How would you like the information displayed?" << endl;
    cout << "Print to screen (Press 1)" << endl;
    cout << "Print to file (Press 2)" << endl;
    cin >> i;
    if (i == 1) {
        for(int h = 0; h < y; h ++) {
            if (!hasevil(spellbookdb, h, y, fi)) {
                cout << spellbookdb[h].title << " " << spellbookdb[h].num_pages << endl;
            } 
        }
    } else if (i == 2) {
        string filename;
        cout << "Please provide the desired filename." << endl;
        cin >> filename;
        ofstream fx(filename, ofstream::trunc);
        for(int h = 0; h < y; h ++) {
            if (!hasevil(spellbookdb, h, y, fi)) {
                fx << spellbookdb[h].title << " " << spellbookdb[h].num_pages << endl;
            }
        }
        cout << "Appended request information to file." << endl;
    }

}
/*************************************************************************************************************************************
** Function: studentsort_effect()
** Description: Looks at array and compares effects of spells in each spellbook and groups and prints to screen
** Parameters: spellbook * spellbookdb, int z, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int z, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void studentsort_effect(spellbook * spellbookdb, int y, ifstream & fi) {
    int i = 0;
    cout << "How would you like the information displayed?" << endl;
    cout << "Print to screen (Press 1)" << endl;
    cout << "Print to file (Press 2)" << endl;
    cin >> i;
    if (i == 1) {
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "bubble" and !hasevil(spellbookdb, g, y, fi)) {
                    cout << "bubble " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "memory_loss" and !hasevil(spellbookdb, g, y, fi)) {
                    cout << "memory_loss " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "fire" and !hasevil(spellbookdb, g, y, fi)) {
                    cout << "fire " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
    } else if (i == 2) {
        studenteffectopt(spellbookdb, y, fi);
    }
}

/*************************************************************************************************************************************
** Function: studenteffectopt()
** Description: Prints sorted information to file
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to file
*************************************************************************************************************************************/
void studenteffectopt(spellbook * spellbookdb, int y, ifstream & fi) {
        ofstream fx("outputs.txt", ofstream::trunc);
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "bubble" and !hasevil(spellbookdb, g, y, fi)) {
                    cout << "bubble " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "memory_loss" and !hasevil(spellbookdb, g, y, fi)) {
                    cout << "memory_loss " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
        for(int g = 0; g < y; g ++) {
            for(int k = 0; k < y; k ++) {
                if(spellbookdb[g].s[k].effect == "fire" and !hasevil(spellbookdb, g, y, fi)) {
                    cout << "fire " << spellbookdb[g].s[k].name << endl;
                }
            }
            
        }
}
/*************************************************************************************************************************************
** Function: studentsort_avg()
** Description: Looks at array and compares success rate of each spellbook and reorders
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void studentsort_avg(spellbook * spellbookdb, int y, ifstream & fi) {
    //sort by avg success rate
    for(int g = 0; g < y; g ++) {
        float total = 0;
        for(int k = 0; k < spellbookdb[g].num_spells; k ++) {
            total = total + spellbookdb[g].s[k].success_rate;
        }
        total = total/(spellbookdb[g].num_spells);
        spellbookdb[g].avg_success_rate = total;
    }
    spellbook hold;
    for(int i = 0; i < y; i ++) {
        for(int j = i; j < y; j++) {
            if (spellbookdb[i].avg_success_rate > spellbookdb[j].avg_success_rate) {
                hold = spellbookdb[j];
                spellbookdb[j] = spellbookdb[i];
                spellbookdb[i] = hold;

            }
        }
    }
    
     studentavgopt(spellbookdb, y, fi);
}

/*************************************************************************************************************************************
** Function: studentavgopt()
** Description: Asks user which display option they prefer
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: return new reordered information to screen or file
*************************************************************************************************************************************/
void studentavgopt(spellbook * spellbookdb, int y, ifstream & fi) {
    int i = 0;
    cout << "How would you like the information displayed?" << endl;
    cout << "Print to screen (Press 1)" << endl;
    cout << "Print to file (Press 2)" << endl;
    cin >> i;
    if (i == 1) {
        for(int h = 0; h < y; h ++) {
            if (!hasevil(spellbookdb, h, y, fi)) {
                cout << spellbookdb[h].title << " " << spellbookdb[h].avg_success_rate << endl;
            } 
        }
    } else if (i == 2) {
        string filename;
        cout << "Please provide the desired filename." << endl;
        cin >> filename;
        ofstream fx(filename, ofstream::trunc);
        for(int h = 0; h < y; h ++) {
            if (!hasevil(spellbookdb, h, y, fi)) {
                fx << spellbookdb[h].title << " " << spellbookdb[h].avg_success_rate << endl;
            } 
        }
        cout << "Appended request information to file." << endl;
    }

}
/*************************************************************************************************************************************
** Function: studentoptions()
** Description: Asks user what option they want and follow through
** Parameters: spellbook * spellbookdb, int y, ifstream & fi
** Pre-conditions: take in spellbook * spellbookdb, int y, ifstream & fi
** Post-conditions: takes user to each option or quits program
*************************************************************************************************************************************/
void studentoptions(spellbook * spellbookdb, int y, ifstream & fi) {
    int x = 0;
    int i = 0;
    cout << "Which option would you like to choose?" << endl;
    cout << "Sort spellbooks by number of pages (Press 1):" << endl;
    cout << "Group spells by their effect (Press 2):" << endl;
    cout << "Sort spellbooks by average success rate (Press 3):" << endl;
    cout << "Quit (Press 4):" << endl;
    cin >> x;

    if (x == 1){
        cout << "Student Option" << endl;
        studentsort_pages(spellbookdb, y, fi);
    }else if (x == 2){
        cout << "Student Option" << endl;
        studentsort_effect(spellbookdb, y, fi);
    }else if (x==3) {
        cout << "Student Option" << endl;
        studentsort_avg(spellbookdb, y, fi);
    }else if (x==4) {
        cout << "You have quit the program." << endl;
    }else {
        cout << "You did not enter a valid option." << endl;
    }
    
}
/*************************************************************************************************************************************
** Function: options()
** Description: Asks user what option they want and follow through
** Parameters: wizards * wizarddb, spellbook * spellbookdb, int h, int y, ifstream & fi
** Pre-conditions: take in wizards * wizarddb, spellbook * spellbookdb, int h, int y, ifstream & fi
** Post-conditions: takes user to each option or quits program
*************************************************************************************************************************************/
void options(wizards * wizarddb, spellbook * spellbookdb, int h, int y, ifstream & fi) {
    if(wizarddb[h].title == "Teacher" or wizarddb[h].title == "Headmaster") {
        int x = 0;
        int i = 0;
        cout << "Which option would you like to choose?" << endl;
        cout << "Sort spellbooks by number of pages (Press 1):" << endl;
        cout << "Group spells by their effect (Press 2):" << endl;
        cout << "Sort spellbooks by average success rate (Press 3):" << endl;
        cout << "Quit (Press 4):" << endl;
        cin >> x;
        if (x == 1){
            sort_pages(spellbookdb, y, fi);
        }else if (x == 2){
            sort_effect(spellbookdb, y, fi);
        }else if (x==3) {
            sort_avg(spellbookdb, y, fi);
        }else if (x==4) {
            cout << "You have quit the program." << endl;
        }else {
            cout << "You did not enter a valid option." << endl;
        }
    } else {
        studentoptions(spellbookdb,  y, fi);
    }
    
}

/*************************************************************************************************************************************
** Function: delete_info()
** Description: Deletes arrays
** Parameters: wizards * wizarddb, spellbook * spellbookdb
** Pre-conditions: take in wizards * wizarddb, spellbook * spellbookdb
** Post-conditions: deletes arrays
*************************************************************************************************************************************/
void delete_info(wizards * wizarddb, spellbook * spellbookdb) {
    delete[] wizarddb;
    delete[] spellbookdb;
}