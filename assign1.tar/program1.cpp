#include "./programfunct.h"

// The Main is more than 10 lines because I had to set up the files and paramaters to be taken in and this caused the main to be longer
int main(int argc, char* argv[]) {
    if (argc == 3) { 
        //This is checking the number of arguments entered
        if ((strcmp(argv[1], "wizards.txt") == 0) and (strcmp(argv[2], "spellbooks.txt") == 0)) {
            //This is checking if the filenames were input correctly
            ifstream f("wizards.txt");
            ifstream fi("spellbooks.txt");
            if (f.is_open() and fi.is_open()){
                //This checks to see if the files are open
                int x, y;
                string str, str2;
                getline(f, str);
                getline(fi, str2);
                x = string_convert(str);
                y = string_convert(str2);
                wizards* wizarddb = create_wizarddb(x);
                spellbook* spellbookdb = create_spellbooks(y);
                while(!f.eof()){
                    //This is saying until it reaches the end of the file
                    get_wizards(wizarddb, x, f);
                }
                while(!fi.eof()) {
                    //This is saying until it reaches the end of the file
                    get_spellbook_data(spellbookdb, y, fi);
                }
                pw_check(wizarddb, spellbookdb, x, y, f, fi);
                delete_info(wizarddb, spellbookdb);
                f.close();
                fi.close();
            }else {
                cout << "Error opening file!" << endl;
                return -1;
            }
        }else {
            //If the incorrect file names were entered, an error message will appear and the program will quit 
            cout << "Please enter the correct file names. (wizards.txt) (spellbooks.txt)" << endl;
            return -1;
        }
    }else {
        //If the number of arguements entered was higher or lower, and error message appears and the program will quit
        cout << "Please enter (wizards.txt) (spellbooks.txt) "<< endl;
        return -1;
    }
    return 0;
}